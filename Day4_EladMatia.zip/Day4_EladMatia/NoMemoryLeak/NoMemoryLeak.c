/*********************************
* Class: MAGSHIMIM C2			 *
* Week:                			 *
* Name:                          *
* Credits:                       *
**********************************/

#include <stdio.h>
#include <stdlib.h>


int main(void)
{

	//Write your code here...
	int* px = (int*)malloc(sizeof(int)); // allocate memory
	free(px); // free the space
	getchar();
	return 0;
}